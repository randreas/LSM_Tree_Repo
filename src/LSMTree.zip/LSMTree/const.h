/*
File to store Constants 
*/
#include <limits.h>

#define TERMINATE	INT_MIN
