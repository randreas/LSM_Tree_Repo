//
// Created by jingyusu on 3/21/22.
//

#ifndef TEMPLATEDB_ITOA_H
#define TEMPLATEDB_ITOA_H

#include <string>
#include <sstream>

std::string itoa(int i);

#endif //TEMPLATEDB_ITOA_H
